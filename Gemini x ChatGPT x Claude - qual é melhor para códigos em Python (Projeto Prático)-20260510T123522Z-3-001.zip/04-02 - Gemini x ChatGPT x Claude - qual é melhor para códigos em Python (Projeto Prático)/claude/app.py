import streamlit as st
import os
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import AIMessage, HumanMessage
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough, RunnableLambda

# ---------------------------------------------------------------------------
# Configuração da página
# ---------------------------------------------------------------------------
st.set_page_config(
    page_title="Consulta RH — Política da Empresa",
    page_icon="📋",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ---------------------------------------------------------------------------
# CSS customizado
# ---------------------------------------------------------------------------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap');

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif;
}

.header-container {
    background: linear-gradient(135deg, #0B1D13 0%, #1B4332 100%);
    border: 1px solid #1E3A2B;
    border-radius: 16px;
    padding: 2rem 2rem 1.5rem;
    margin-bottom: 1.5rem;
    text-align: center;
}
.header-container h1 {
    color: #D8F3DC;
    font-size: 1.75rem;
    font-weight: 600;
    margin: 0 0 .35rem;
    letter-spacing: -0.02em;
}
.header-container p {
    color: #95D5B2;
    font-size: .95rem;
    margin: 0;
}
.status-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: #122A1C;
    border: 1px solid #52B788;
    color: #52B788;
    font-size: .8rem;
    font-weight: 500;
    padding: 4px 14px;
    border-radius: 999px;
    margin-top: .75rem;
}
.status-pill .dot {
    width: 7px; height: 7px;
    background: #52B788;
    border-radius: 50%;
}
.stChatMessage {
    border-radius: 12px !important;
    margin-bottom: .5rem !important;
}
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# Carregar variáveis de ambiente
# ---------------------------------------------------------------------------
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
PDF_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "politica_rh.pdf")
VECTORSTORE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".vectorstore")


# ---------------------------------------------------------------------------
# Funções auxiliares
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner="Processando o documento de política de RH…")
def build_vectorstore() -> FAISS:
    """Carrega o PDF, divide em chunks e cria/carrega o índice FAISS."""
    embeddings = OpenAIEmbeddings(
        model="text-embedding-3-small",
        openai_api_key=OPENAI_API_KEY,
    )

    if os.path.exists(VECTORSTORE_DIR):
        return FAISS.load_local(
            VECTORSTORE_DIR, embeddings, allow_dangerous_deserialization=True
        )

    loader = PyPDFLoader(PDF_PATH)
    pages = loader.load()

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    docs = splitter.split_documents(pages)

    vectorstore = FAISS.from_documents(docs, embeddings)
    vectorstore.save_local(VECTORSTORE_DIR)
    return vectorstore


def build_rag_chain(vectorstore: FAISS):
    """
    Cria a cadeia RAG conversacional usando LCEL puro (langchain_core),
    sem depender de langchain.chains (removido no LangChain 1.x).
    """

    llm = ChatOpenAI(
        model="gpt-4o-mini",
        temperature=0.1,
        openai_api_key=OPENAI_API_KEY,
    )

    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": 5},
    )

    # --- 1. Prompt para contextualizar a pergunta ---
    contextualize_q_prompt = ChatPromptTemplate.from_messages([
        ("system",
         "Dado o histórico da conversa abaixo e a última pergunta do usuário "
         "(que pode fazer referência a algo do histórico), reformule a pergunta "
         "para que ela possa ser entendida de forma independente, sem precisar do "
         "histórico. NÃO responda à pergunta — apenas reformule-a se necessário, "
         "ou devolva-a como está."),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])

    # Chain que reformula a pergunta com base no histórico
    contextualize_chain = contextualize_q_prompt | llm | StrOutputParser()

    def _get_retriever_query(data: dict) -> str:
        """Se houver histórico, reformula a pergunta; senão, usa a original."""
        if data.get("chat_history"):
            return contextualize_chain.invoke(data)
        return data["input"]

    # --- 2. Prompt principal de QA ---
    qa_system_prompt = """Você é o assistente virtual de Recursos Humanos da empresa.
Seu ÚNICO papel é responder perguntas sobre a **Política de RH** da empresa com base
exclusivamente no conteúdo do documento fornecido abaixo.

Regras que você DEVE seguir rigorosamente:
1. Responda APENAS com informações presentes no contexto fornecido.
2. Se a pergunta NÃO puder ser respondida com o conteúdo do documento, diga exatamente:
   "Desculpe, não tenho essa informação. Minha base de conhecimento se limita à política \
de RH da empresa. Para essa dúvida, recomendo entrar em contato diretamente com o setor \
de Recursos Humanos."
3. Nunca invente, suponha ou extrapole informações que não estejam no documento.
4. Seja claro, objetivo e amigável nas respostas.
5. Quando relevante, cite a seção ou trecho do documento que embasa sua resposta.
6. Responda sempre em português brasileiro.
7. Se a pergunta for sobre um assunto completamente fora do escopo de RH \
(ex.: receitas, esportes, programação etc.), diga educadamente que você só pode \
ajudar com questões relacionadas à política de RH da empresa.

Contexto do documento:
{context}"""

    qa_prompt = ChatPromptTemplate.from_messages([
        ("system", qa_system_prompt),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])

    def _format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    def _invoke_rag(data: dict) -> dict:
        """Executa o pipeline RAG completo e retorna resposta + fontes."""
        # 1. Reformular pergunta se necessário
        query = _get_retriever_query(data)

        # 2. Buscar documentos relevantes
        retrieved_docs = retriever.invoke(query)

        # 3. Montar contexto e gerar resposta
        context_text = _format_docs(retrieved_docs)
        response = qa_prompt | llm | StrOutputParser()
        answer = response.invoke({
            "context": context_text,
            "chat_history": data.get("chat_history", []),
            "input": data["input"],
        })

        return {
            "answer": answer,
            "context": retrieved_docs,
        }

    return _invoke_rag


# ---------------------------------------------------------------------------
# Converter histórico do session_state para formato LangChain
# ---------------------------------------------------------------------------
def get_chat_history() -> list:
    """Converte o histórico do st.session_state para objetos LangChain."""
    history = []
    for msg in st.session_state.get("messages", []):
        if msg["role"] == "user":
            history.append(HumanMessage(content=msg["content"]))
        elif msg["role"] == "assistant":
            history.append(AIMessage(content=msg["content"]))
    return history


# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------
st.markdown("""
<div class="header-container">
    <h1>📋 Consulta — Política de RH</h1>
    <p>Tire suas dúvidas sobre a política de Recursos Humanos da empresa.</p>
    <div class="status-pill"><span class="dot"></span> Assistente online</div>
</div>
""", unsafe_allow_html=True)

# Verificações iniciais
if not OPENAI_API_KEY:
    st.error("⚠️ Chave da API da OpenAI não encontrada. Crie um arquivo `.env` com `OPENAI_API_KEY=sk-...`")
    st.stop()

if not os.path.exists(PDF_PATH):
    st.error("⚠️ Arquivo `politica_rh.pdf` não encontrado na pasta do projeto.")
    st.stop()

# Inicializar vectorstore e chain
vectorstore = build_vectorstore()
rag_invoke = build_rag_chain(vectorstore)

# Inicializar histórico de mensagens
if "messages" not in st.session_state:
    st.session_state.messages = []

# Mensagem de boas-vindas
if not st.session_state.messages:
    welcome = (
        "Olá! 👋 Sou o assistente virtual de RH da empresa. "
        "Estou aqui para responder suas dúvidas sobre a **política de Recursos Humanos**.\n\n"
        "Pode perguntar sobre férias, benefícios, jornada de trabalho, código de conduta "
        "e qualquer outro tema coberto pela nossa política. Como posso ajudar?"
    )
    st.session_state.messages.append({"role": "assistant", "content": welcome})

# Exibir mensagens anteriores
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

# Input do usuário
if prompt := st.chat_input("Digite sua pergunta sobre a política de RH…"):
    # Exibir mensagem do usuário
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Gerar resposta
    with st.chat_message("assistant"):
        with st.spinner("Consultando a política de RH…"):
            # Monta o histórico SEM a mensagem atual do user (já vai no "input")
            chat_history = get_chat_history()[:-1]

            # Limitar histórico às últimas 40 mensagens (20 pares)
            chat_history = chat_history[-40:]

            result = rag_invoke({
                "input": prompt,
                "chat_history": chat_history,
            })

            answer = result["answer"]

        st.markdown(answer)

        # Mostrar fontes em um expander
        sources = result.get("context", [])
        if sources:
            unique_pages = sorted(set(doc.metadata.get("page", 0) + 1 for doc in sources))
            with st.expander(f"📄 Fontes consultadas — Páginas: {', '.join(map(str, unique_pages))}"):
                for i, doc in enumerate(sources):
                    page = doc.metadata.get("page", 0) + 1
                    st.markdown(f"**Trecho {i+1}** (Página {page}):")
                    st.caption(doc.page_content[:300] + ("…" if len(doc.page_content) > 300 else ""))
                    if i < len(sources) - 1:
                        st.divider()

    st.session_state.messages.append({"role": "assistant", "content": answer})

# Sidebar com info e botão de limpar
with st.sidebar:
    st.markdown("### ⚙️ Sobre")
    st.markdown(
        "Este assistente utiliza **RAG** (Retrieval-Augmented Generation) "
        "para responder perguntas com base exclusivamente no documento "
        "de política de RH da empresa."
    )
    st.divider()
    st.markdown("### 📊 Sessão atual")
    n_msgs = len([m for m in st.session_state.messages if m["role"] == "user"])
    st.markdown(f"**Perguntas feitas:** {n_msgs}")
    st.divider()
    if st.button("🗑️ Limpar conversa", use_container_width=True):
        st.session_state.messages = []
        st.rerun()