import os
from typing import List

import streamlit as st
from dotenv import load_dotenv

from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter

from langchain_chroma import Chroma

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from langchain_core.runnables import RunnablePassthrough
from langchain_core.messages import HumanMessage, AIMessage

# ----------------------------
# Config
# ----------------------------
PDF_FILENAME = "politica_rh.pdf"
PERSIST_DIR = "rag_storage"  # pasta para persistir o Chroma
COLLECTION_NAME = "politica_rh"

# Ajustes de chunk (bom para políticas longas)
CHUNK_SIZE = 1200
CHUNK_OVERLAP = 200

# Recuperação
TOP_K = 5  # quantos trechos recuperar

# LLM
MODEL_NAME = "gpt-4o-mini"
TEMPERATURE = 0.2

# ----------------------------
# Prompt (com guardrails)
# ----------------------------
SYSTEM_POLICY = """\
Você é um assistente de RH interno. Responda SOMENTE usando o contexto fornecido (trechos da política de RH da empresa).
Se a resposta não estiver explicitamente no contexto, diga exatamente:
"Não sei responder com base na Política de RH disponível, pois não tenho acesso a essa informação."
Não invente, não faça suposições e não use conhecimento externo.
Se a pergunta for sobre algo fora da política (por ex.: leis externas, casos pessoais, dados de funcionários, salários específicos), responda com a mesma frase de desconhecimento.
Responda em português do Brasil, de forma detalhada e objetiva.
"""

PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", SYSTEM_POLICY),
        ("system", "Histórico da conversa (pode conter referências importantes do usuário):\n{chat_history}"),
        ("human", "Pergunta do usuário: {question}\n\nContexto (trechos da Política de RH):\n{context}"),
    ]
)

# ----------------------------
# Utilidades
# ----------------------------
def format_docs(docs) -> str:
    """Concatena documentos recuperados, com metadados úteis."""
    parts = []
    for d in docs:
        page = d.metadata.get("page", None)
        source = d.metadata.get("source", "")
        header = f"[Fonte: {os.path.basename(source)}"
        if page is not None:
            header += f" | página {page + 1}"
        header += "]"
        parts.append(f"{header}\n{d.page_content}")
    return "\n\n---\n\n".join(parts)

def format_chat_history(messages: List) -> str:
    """Converte histórico em texto curto para o prompt (evita explodir tokens)."""
    messages = messages or []

    # Mantém somente as últimas N interações para caber no contexto
    MAX_TURNS = 12
    trimmed = messages[-(MAX_TURNS * 2):]  # ~12 pares user/assistant

    lines = []
    for m in trimmed:
        if isinstance(m, HumanMessage):
            lines.append(f"Usuário: {m.content}")
        elif isinstance(m, AIMessage):
            lines.append(f"Assistente: {m.content}")
    return "\n".join(lines)

@st.cache_resource(show_spinner=False)
def build_or_load_vectorstore() -> Chroma:
    """Carrega ou cria o vetorstore persistido em disco."""
    if not os.path.exists(PDF_FILENAME):
        raise FileNotFoundError(
            f"Não encontrei o arquivo '{PDF_FILENAME}' na pasta do projeto."
        )

    embeddings = OpenAIEmbeddings(model="text-embedding-3-large")

    # Se já existe base persistida, abre
    if os.path.exists(PERSIST_DIR) and os.listdir(PERSIST_DIR):
        vs = Chroma(
            collection_name=COLLECTION_NAME,
            embedding_function=embeddings,
            persist_directory=PERSIST_DIR,
        )
        return vs

    # Caso contrário, cria do zero a partir do PDF
    loader = PyPDFLoader(PDF_FILENAME)
    docs = loader.load()

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP,
        separators=["\n\n", "\n", ".", "!", "?", ";", ",", " ", ""],
    )
    chunks = splitter.split_documents(docs)

    vs = Chroma.from_documents(
        documents=chunks,
        embedding=embeddings,
        collection_name=COLLECTION_NAME,
        persist_directory=PERSIST_DIR,
    )
    return vs

def make_rag_chain(vectorstore: Chroma):
    retriever = vectorstore.as_retriever(search_kwargs={"k": TOP_K})

    llm = ChatOpenAI(
        model=MODEL_NAME,
        temperature=TEMPERATURE,
    )

    rag_chain = (
        {
            "context": retriever | format_docs,
            "question": RunnablePassthrough(),
            # ✅ safe: não quebra se session_state ainda não tiver a chave
            "chat_history": lambda _: format_chat_history(st.session_state.get("chat_messages", [])),
        }
        | PROMPT
        | llm
        | StrOutputParser()
    )
    return rag_chain, retriever

# ----------------------------
# Streamlit UI
# ----------------------------
def main():
    load_dotenv()
    st.set_page_config(page_title="Chat RH (Política de RH)", page_icon="💬", layout="wide")

    # ✅ Inicialize o estado o mais cedo possível (corrige AttributeError)
    st.session_state.setdefault("chat_messages", [])
    st.session_state.setdefault("ui_messages", [])

    st.title("💬 Chat RH — Política de RH (RAG)")
    st.caption("Responde somente com base no arquivo politica_rh.pdf. Perguntas fora do documento: 'não sei'.")

    # Checa chave
    if not os.getenv("OPENAI_API_KEY"):
        st.error("OPENAI_API_KEY não encontrada. Crie um arquivo .env com OPENAI_API_KEY=... na pasta do projeto.")
        st.stop()

    # Sidebar
    with st.sidebar:
        st.header("Configurações")
        st.write(f"Modelo: `{MODEL_NAME}`")
        st.write(f"Top K: `{TOP_K}`")
        st.write(f"Chunk: `{CHUNK_SIZE}` / overlap `{CHUNK_OVERLAP}`")

        if st.button("🔄 Reindexar PDF (recriar base)", use_container_width=True):
            # Apaga persistência e recarrega
            if os.path.exists(PERSIST_DIR):
                for root, dirs, files in os.walk(PERSIST_DIR, topdown=False):
                    for name in files:
                        try:
                            os.remove(os.path.join(root, name))
                        except Exception:
                            pass
                    for name in dirs:
                        try:
                            os.rmdir(os.path.join(root, name))
                        except Exception:
                            pass
                try:
                    os.rmdir(PERSIST_DIR)
                except Exception:
                    pass

            st.cache_resource.clear()
            st.success("Base removida. Recarregue a página para reindexar.")
            st.stop()

        if st.button("🧹 Limpar conversa", use_container_width=True):
            st.session_state["chat_messages"] = []
            st.session_state["ui_messages"] = []
            st.rerun()

    # Inicializa vetorstore e chain
    try:
        vectorstore = build_or_load_vectorstore()
    except FileNotFoundError as e:
        st.error(str(e))
        st.stop()

    rag_chain, retriever = make_rag_chain(vectorstore)

    # Render histórico (UI)
    for role, content in st.session_state["ui_messages"]:
        with st.chat_message(role):
            st.markdown(content)

    # Entrada do usuário
    user_input = st.chat_input("Pergunte algo sobre a Política de RH...")
    if user_input:
        # Mostra msg do user
        st.session_state["ui_messages"].append(("user", user_input))
        st.session_state["chat_messages"].append(HumanMessage(content=user_input))

        with st.chat_message("user"):
            st.markdown(user_input)

        # Resposta com spinner
        with st.chat_message("assistant"):
            with st.spinner("Consultando a Política de RH..."):
                docs = retriever.get_relevant_documents(user_input)
                answer = rag_chain.invoke(user_input)

                st.markdown(answer)

                with st.expander("📚 Ver trechos usados como base (fontes)"):
                    if docs:
                        for i, d in enumerate(docs, start=1):
                            page = d.metadata.get("page", None)
                            page_txt = f"página {page + 1}" if page is not None else "página ?"
                            st.markdown(f"**Trecho {i} — {page_txt}**")
                            st.write(d.page_content)
                            st.markdown("---")
                    else:
                        st.write("Nenhum trecho recuperado.")

        # Salva msg do assistente
        st.session_state["ui_messages"].append(("assistant", answer))
        st.session_state["chat_messages"].append(AIMessage(content=answer))


if __name__ == "__main__":
    main()