import streamlit as st
import os
from dotenv import load_dotenv

# Importações do ecossistema LangChain
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS

# IMPORTAÇÕES ATUALIZADAS (Resolvendo o erro de módulo não encontrado)
from langchain_classic.chains import create_history_aware_retriever, create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import HumanMessage, AIMessage

# Carrega as variáveis de ambiente (arquivo .env)
load_dotenv()

# Configuração da página do Streamlit
st.set_page_config(page_title="Assistente de RH", page_icon="🏢")
st.title("🏢 Chatbot - Política de RH")
st.write("Faça perguntas sobre a política de Recursos Humanos da empresa.")

# -------------------------------------------------------------------
# PROCESSAMENTO DO PDF E VETORIZAÇÃO (Usando Cache para performance)
# -------------------------------------------------------------------
@st.cache_resource(show_spinner="Lendo a política de RH...")
def init_rag_chain():
    # 1. Carregar o documento
    pdf_path = "politica_rh.pdf"
    if not os.path.exists(pdf_path):
        st.error(f"Arquivo não encontrado: {pdf_path}. Certifique-se de colocá-lo na mesma pasta do projeto.")
        st.stop()
        
    loader = PyPDFLoader(pdf_path)
    docs = loader.load()
    
    # 2. Dividir o texto em pedaços (chunks)
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    splits = text_splitter.split_documents(docs)
    
    # 3. Criar o Vector Store (Base de Conhecimento)
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(splits, embeddings)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 4})
    
    # 4. Configurar o LLM
    # Temperatura 0 para respostas mais objetivas e focadas nos fatos
    llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0) 
    
    # 5. Prompt para contextualizar perguntas com base no histórico
    contextualize_q_system_prompt = (
        "Dada uma história de conversa e a última pergunta do usuário "
        "que pode fazer referência ao contexto no histórico de chat, "
        "formule uma pergunta independente que possa ser entendida "
        "sem o histórico de chat. NÃO responda à pergunta, "
        "apenas reformule-a se necessário e, caso contrário, retorne-a como está."
    )
    contextualize_q_prompt = ChatPromptTemplate.from_messages([
        ("system", contextualize_q_system_prompt),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])
    
    history_aware_retriever = create_history_aware_retriever(
        llm, retriever, contextualize_q_prompt
    )
    
    # 6. Prompt principal (Guardrails: responder SOMENTE sobre o PDF)
    qa_system_prompt = (
        "Você é um assistente virtual de Recursos Humanos da empresa. "
        "Sua tarefa é responder a perguntas dos funcionários SOMENTE com base no contexto fornecido abaixo, que é a política de RH da empresa. "
        "Se a resposta não estiver no contexto fornecido, você DEVE dizer: "
        "'Desculpe, não tenho essa informação na política de RH da empresa.' "
        "Sob nenhuma circunstância você deve inventar informações, dar opiniões pessoais, ou responder a perguntas fora do contexto da política de RH.\n\n"
        "Contexto:\n{context}"
    )
    qa_prompt = ChatPromptTemplate.from_messages([
        ("system", qa_system_prompt),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])
    
    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt)
    rag_chain = create_retrieval_chain(history_aware_retriever, question_answer_chain)
    
    return rag_chain

# Inicializa o sistema RAG
rag_chain = init_rag_chain()

# -------------------------------------------------------------------
# GERENCIAMENTO DE MEMÓRIA (Sessão do Streamlit)
# -------------------------------------------------------------------
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

# Exibe o histórico do chat na interface
for msg in st.session_state.chat_history:
    role = "user" if isinstance(msg, HumanMessage) else "assistant"
    with st.chat_message(role):
        st.markdown(msg.content)

# -------------------------------------------------------------------
# INTERAÇÃO COM O USUÁRIO
# -------------------------------------------------------------------
user_input = st.chat_input("Digite sua dúvida sobre a política de RH...")

if user_input:
    # Mostra a mensagem do usuário imediatamente
    with st.chat_message("user"):
        st.markdown(user_input)
        
    # Exibe um indicador de "digitando" enquanto processa a resposta
    with st.chat_message("assistant"):
        with st.spinner("Buscando na política de RH..."):
            # Chama a cadeia RAG passando a pergunta e o histórico atual
            response = rag_chain.invoke({
                "input": user_input,
                "chat_history": st.session_state.chat_history
            })
            
            answer = response["answer"]
            st.markdown(answer)
            
    # Atualiza a memória com a nova interação
    st.session_state.chat_history.extend([
        HumanMessage(content=user_input),
        AIMessage(content=answer)
    ])